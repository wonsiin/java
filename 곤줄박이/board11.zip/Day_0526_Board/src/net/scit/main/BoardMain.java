package net.scit.main;

import net.scit.ui.BoardUI;

public class BoardMain {
	public static void main(String[] args) {
		new BoardUI();
	}

}
